import tkinter as tk
from tkinter import messagebox, font
import json
from PIL import ImageTk, Image  # Для работы с изображениями
import os  # Для проверки существования файлов

# Глобальные переменные
current_theme = None
data = None
background_label = None
alphabet_frame = None
inner_frame = None
current_bg_index = 0

# Определение функций

def load_data():
    """Функция для загрузки данных из JSON-файла"""
    DATA_FILE_PATH = r'C:\Users\user\Desktop\модуль 3\data.json'
    try:
        with open(DATA_FILE_PATH, 'r', encoding='utf-8') as file:
            return json.load(file)
    except FileNotFoundError:
        messagebox.showerror("Ошибка", "Файл данных не найден.")
        return {}

def change_background():
    """Функция для смены фона"""
    global current_bg_index
    current_bg_index = (current_bg_index + 1) % len(loaded_images)
    new_photo = loaded_images[current_bg_index]
    background_label.config(image=new_photo)
    background_label.image = new_photo

def create_article_window(letter, article_text):
    """Функция для создания нового окна с информацией"""
    article_window = tk.Toplevel(root)
    article_window.config(bg=current_theme['bg'], cursor='cross')  # Добавили курсор-крестик
    article_window.title(f"Содержимое для буквы '{letter}'")
    
    # Добавляем текст в окно
    label_font = font.Font(family=current_theme['font'][0], size=current_theme['font'][1])
    text_label = tk.Label(article_window, text=article_text, wraplength=500, justify="left", fg=current_theme['fg'], bg=current_theme['bg'], font=label_font)
    text_label.pack(padx=20, pady=10)
    
    # Кнопка закрытия окна
    close_button = tk.Button(article_window, text="Закрыть", command=article_window.destroy, fg=current_theme['fg'], bg=current_theme['bg'], font=label_font)
    close_button.pack(pady=10)

def handle_letter_selection(char):
    """Функция для обработки выбора буквы"""
    global data
    if char in data:
        article_text = data[char]
    else:
        article_text = f"Нет информации для буквы {char}"
    create_article_window(char, article_text)

def switch_theme():
    """Функция для переключения тем"""
    global current_theme
    if current_theme == THEME_LIGHT:
        current_theme = THEME_DARK
    else:
        current_theme = THEME_LIGHT
    apply_theme(current_theme)

def apply_theme(theme):
    """Функция для применения текущей темы ко всем виджетам"""
    global root, background_label, alphabet_frame, inner_frame
    root.config(bg=theme['bg'], cursor='cross')  # Добавили курсор-крестик
    background_label.config(bg=theme['bg'])
    alphabet_frame.config(bg=theme['bg'])
    inner_frame.config(bg=theme['bg'])
    for widget in root.winfo_children():
        widget.config(bg=theme['bg'], fg=theme['fg'], font=theme['font'])

# Настройка главного окна приложения

root = tk.Tk()
root.title("Настольная энциклопедия 'Хочу всё знать 2025'")

# Получение размеров экрана
screen_width = root.winfo_screenwidth()
screen_height = root.winfo_screenheight()

# Тема оформления
THEME_LIGHT = {'bg': '#ffffff', 'fg': '#000000', 'font': ('Arial', 14)}
THEME_DARK = {'bg': '#333333', 'fg': '#ffffff', 'font': ('Arial', 14)}

# Выбор начальной темы
current_theme = THEME_LIGHT

# Загружаем данные из JSON файла
data = load_data()

# Определение путей к фоновым изображениям
BACKGROUND_IMAGE_PATHS = [
    r'C:\Users\user\Desktop\модуль 3\background.jpg',
    r'C:\Users\user\Desktop\модуль 3\another_background.jpg'  # Добавьте другие изображения здесь
]

loaded_images = []

# Загрузка изображений
for path in BACKGROUND_IMAGE_PATHS:
    if not os.path.exists(path):
        print(f"Путь к изображению {path} не существует!")
        continue
    img = Image.open(path)
    resized_img = img.resize((screen_width, screen_height), Image.Resampling.LANCZOS)
    loaded_images.append(ImageTk.PhotoImage(resized_img))

# Создаем фоновое изображение
image_path = r'C:\Users\user\Desktop\модуль 3\background.jpg'  # Путь к изображению фона
if os.path.exists(image_path):
    background_image = Image.open(image_path)
else:
    print(f"Путь к изображению {image_path} не существует! Фон не отображается.")
    background_image = None

if background_image:
    resized_image = background_image.resize((screen_width, screen_height), Image.Resampling.LANCZOS)
    background_photo = ImageTk.PhotoImage(resized_image)
    background_label = tk.Label(root, image=background_photo)
    background_label.image = background_photo  # Сохраняем ссылку на изображение
    background_label.place(x=0, y=0, relwidth=1, relheight=1)

# Создание рамки для алфавитной панели
alphabet_frame = tk.Frame(root, bg=current_theme['bg'], height=100)  # Увеличили высоту панели
alphabet_frame.pack(pady=20, fill='x')

# Горизонтальная прокрутка
scrollbar_x = tk.Scrollbar(alphabet_frame, orient='horizontal')
scrollbar_x.pack(side='bottom', fill='x')

# Канавс для кнопок
canvas = tk.Canvas(alphabet_frame, xscrollcommand=scrollbar_x.set, height=80)  # Увеличили высоту Canvas
canvas.pack(side='top', fill='both', expand=True)

# Связывание скроллбара с канвасом
scrollbar_x.config(command=canvas.xview)

# Внутренняя рамка для кнопок
inner_frame = tk.Frame(canvas, bg=current_theme['bg'])
inner_frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
canvas.create_window((0, 0), window=inner_frame, anchor='nw')

# Динамическое создание кнопок для каждой буквы
for char in 'АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ':
    if char in data:
        first_word = data[char].split()[0]  # Получаем первое слово из статьи
    else:
        first_word = ""
    button = tk.Button(inner_frame, text=f"{char}: {first_word}", width=10, height=1, command=lambda c=char: handle_letter_selection(c), fg=current_theme['fg'], bg=current_theme['bg'], font=current_theme['font'])
    button.pack(side='left')

# Кнопка смены фона
background_change_button = tk.Button(
    root,
    text="Сменить фон",
    command=change_background,
    fg=current_theme['fg'],
    bg=current_theme['bg'],
    font=current_theme['font']
)
background_change_button.pack(side='right', anchor='se', padx=10, pady=10)

# Кнопка переключения тем
theme_switch_button = tk.Button(
    root,
    text="Темная / Светлая",
    command=switch_theme,
    fg=current_theme['fg'],
    bg=current_theme['bg'],
    font=current_theme['font']
)
theme_switch_button.pack(side='right', anchor='ne', padx=10, pady=10)

# Запуск основного цикла
root.mainloop()